# Welcome to Funkin Compiler's template project

This is a simple template to get you started with V-Slice modding

### How do I run/test this mod?

Run the "compiler.exe" program and either choose `run` or `export` command.

In VS Code there're also tasks for those actions in "Run and Debug"
